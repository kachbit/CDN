# Caret.js

A Javascript plugin for customizable terminal-style carets. 

## Changelist
- **beta1.1** (Current)
    - Added support for maxlength
- beta1.0
    - Initial commit, taken from a project
    - Adapt to general inputs
    - Supports multiple inputs

## To-Do
- Fix overflow issues
- Add more customization options